drop schema imdb;
create schema imdb;

use  imdb;

create table Title(
TitleType nvarchar(25) not null,
TitleName nvarchar(250) not null,
TitleReleaseYear nvarchar(5), 
TitleIsAdult int not null,
primary key (TitleType,TitleName)
);


create table 
Titlegenres
(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
Genre nvarchar(200),
primary key (TitleType,TitleName, Genre),

foreign key (TitleType,TitleName) references Title (TitleType,TitleName) 
);


create table 
Titleratings
(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
NumVotes int,
AverageRatings int,
primary key (TitleType,TitleName,NumVotes,AverageRatings),
foreign key (TitleType,TitleName) references Title (TitleType,TitleName) 
);

create table titleAlternateName
(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
title_language nvarchar (5),
region nvarchar (5),
alternate_title nvarchar(500),
primary key (TitleType, TitleName, title_language, region, alternate_title),
foreign key (TitleType,TitleName) references Title (TitleType,TitleName) 
);

create table 
videogame
(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
playtime nvarchar(5),
primary key (TitleType,TitleName,playtime),
foreign key (TitleType,TitleName) references Title (TitleType,TitleName) 
);

create table 
movie
(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
movie_length nvarchar(5),
primary key (TitleType,TitleName,movie_length),
foreign key (TitleType,TitleName) references Title (TitleType,TitleName) 
);


create table 
video
(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
video_length nvarchar(5),
primary key (TitleType,TitleName,video_length),
foreign key (TitleType,TitleName) references Title (TitleType,TitleName) 
);


create table 
tvepisode
(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
episode_length nvarchar(5),
primary key (TitleType,TitleName,episode_length),
foreign key (TitleType,TitleName) references Title (TitleType,TitleName) 
);

create table 
tvseries
(
TitleType nvarchar(25),
TitleName nvarchar(250),
end_year nvarchar(5),
runtime nvarchar(5),
primary key (TitleType,TitleName,end_year),
foreign key (TitleType,TitleName) references Title (TitleType,TitleName) 
);

create table belongs(
E_TitleType nvarchar(25) ,
E_TitleName nvarchar(200),
E_releaseYear nvarchar(8),
season int,
episode_number int,
S_TitleType nvarchar(25),
S_TitleName nvarchar(200),
end_year nvarchar(5),
s_releaseYear nvarchar(8),
primary key (E_TitleType,E_TitleName,S_TitleType,S_TitleName,end_year,season,episode_number),
foreign key (E_TitleType,E_TitleName) references tvepisode(TitleType,TitleName),
foreign key (S_TitleType,S_TitleName,end_year) references tvseries (TitleType,TitleName,end_year)
);


create table Person(
PersonName nvarchar(200), 
BirthYear nvarchar(5) ,
DeathYear nvarchar(5),
primary key (PersonName,BirthYear)
);

create table writer(
PersonName nvarchar(200), 
BirthYear nvarchar(5) ,
writer_category nvarchar(8),
primary key (PersonName,BirthYear),
foreign key (PersonName,BirthYear) references Person(PersonName,BirthYear)
);


create table 
title_writer(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
PersonName nvarchar(200), 
BirthYear nvarchar(5) ,
specialization nvarchar(80),
primary key (TitleType,TitleName,PersonName,BirthYear,specialization),
foreign key (TitleType,TitleName) references title(TitleType,TitleName),
foreign key (PersonName,BirthYear) references writer (PersonName,BirthYear)
);


create table director(
PersonName nvarchar(200), 
BirthYear nvarchar(50) ,
category nvarchar(80) ,
primary key (PersonName,BirthYear,category),
foreign key (PersonName,BirthYear) references Person(PersonName,BirthYear)
);

create table 
title_director(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
PersonName nvarchar(200), 
BirthYear nvarchar(5) ,
director_type nvarchar(80),
primary key (TitleType,TitleName,PersonName,BirthYear,director_type),
foreign key (TitleType,TitleName) references title(TitleType,TitleName),
foreign key (PersonName,BirthYear) references person (PersonName,BirthYear)
);


create table actor(
PersonName nvarchar(200), 
BirthYear nvarchar(50) ,
actor_category nvarchar(20),
primary key (PersonName,BirthYear,actor_category),
foreign key (PersonName,BirthYear) references Person(PersonName,BirthYear)
);

create table title_actor(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
PersonName nvarchar(200), 
BirthYear nvarchar(5) ,
actor_category nvarchar(20),
character_played nvarchar(400),
primary key (TitleType,TitleName,PersonName,BirthYear,character_played),
foreign key (TitleType,TitleName) references title(TitleType,TitleName),
foreign key (PersonName,BirthYear,actor_category) references actor (PersonName,BirthYear,actor_category)
);

create table credit(
PersonName nvarchar(200), 
BirthYear nvarchar(50) ,
category nvarchar(20),
primary key (PersonName,BirthYear,category),
foreign key (PersonName,BirthYear) references Person(PersonName,BirthYear)
);

create table title_credit(
TitleType nvarchar(25) ,
TitleName nvarchar(250),
PersonName nvarchar(200), 
BirthYear nvarchar(5) ,
category nvarchar(90),
job nvarchar(90),
primary key (TitleType,TitleName,PersonName,BirthYear,job),
foreign key (TitleType,TitleName) references title(TitleType,TitleName),
foreign key (PersonName,BirthYear,category) references credit (PersonName,BirthYear,category)
);


